package com.exam.examportalbackend.services.impl;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.exam.examportalbackend.model.User;
import com.exam.examportalbackend.model.UserRole;
import com.exam.examportalbackend.repository.RoleRepository;
import com.exam.examportalbackend.repository.UserRepository;
import com.exam.examportalbackend.services.UserService;

public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	
	@Override
	public User createUser(User user, Set<UserRole> userRoles) {
		User userExsist=userRepository.findByUsername(user.getUsername());
		if(userExsist!=null) {
			new RuntimeException("User name "+ user.getUsername() +" is already Exist");
		}else {
			//create User
			for(UserRole roles:userRoles) {
				roleRepository.save(roles.getRole());
			}
			user.getUserRole().addAll(userRoles);
			userExsist = this.userRepository.save(user);	
		}
		return userExsist;
	}
	
	public UserRepository getUserRepository() {
		return userRepository;
	}
	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
	public RoleRepository getRoleRepository() {
		return roleRepository;
	}
	public void setRoleRepository(RoleRepository roleRepository) {
		this.roleRepository = roleRepository;
	}
	

}
