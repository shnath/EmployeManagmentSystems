package com.exam.examportalbackend.services;

import java.util.Set;

import com.exam.examportalbackend.model.User;
import com.exam.examportalbackend.model.UserRole;

public interface UserService {
	public User createUser(User user,Set<UserRole> userRole);
}
