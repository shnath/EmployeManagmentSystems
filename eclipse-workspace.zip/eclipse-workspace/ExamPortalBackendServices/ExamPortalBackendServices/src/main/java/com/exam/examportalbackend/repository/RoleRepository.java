package com.exam.examportalbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.exam.examportalbackend.model.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {

}
