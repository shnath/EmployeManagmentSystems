package com.exam.examportalbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exam.examportalbackend.model.User;

public interface UserRepository extends JpaRepository<User, Long>{

	User findByUsername(String username);

}
