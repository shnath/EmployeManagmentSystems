package com.exam.examportalbackend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exam.examportalbackend.model.User;
import com.exam.examportalbackend.services.impl.UserServiceImpl;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserServiceImpl userService;
	
	//create user service
	@PostMapping("/create")
	public User createUser(@RequestBody User user) {
		return userService.createUser(user, null);
	}
}
