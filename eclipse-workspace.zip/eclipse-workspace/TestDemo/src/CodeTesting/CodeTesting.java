package CodeTesting;

import java.util.ArrayList;
import java.util.Arrays;

public class CodeTesting {

	String caseComments = "AccountNumbers:0509621256||Comment:shifting";

	String accountNumber = "333";

	public static void main(String[] args) {
		//new CodeTesting().caseComments();
		System.out.print(Long.parseLong("99999999999999"));
	}

	public void caseComments() {

			String[] commentValues = this.getCaseComments().split("\\|\\|");
			String[] sa = commentValues[0].split(":");
			String[] accountNumbers = sa[1].split(",");

			String[] accountList = null;
			if (this.getAccountNumber() != null && this.getAccountNumber().length() > 0) {
				accountList = new String[accountNumbers.length + 1];
				accountList[0] = this.getAccountNumber();
				for (int i = 0; i < accountList.length - 1; i++) {
					accountList[i + 1] = accountNumbers[i];
				}
//                     response.setAccountNumber(accountList);
				System.out.print(new ArrayList<>(Arrays.asList(accountList)).toString());

			} else {
				System.out.print(new ArrayList<>(Arrays.asList(accountNumbers)).toString());

			}

			// response.setAccountNumber(accountList);


	}

	public String getAccountNumber() {
		return accountNumber;
	}

	private String getCaseComments() {
		return caseComments;
	}
}
