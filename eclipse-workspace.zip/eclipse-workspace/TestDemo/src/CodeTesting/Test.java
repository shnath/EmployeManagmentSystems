package CodeTesting;
public class Test {

    public static void main(String args[]) {
    	 String s1 = "hello";
         String s2 = new String("hello");
         System.out.println(s1 == s2);//It will print false s1 in Constant Pool and s2 store in Heap 
         //intern() The method intern() creates an exact copy of a String object in the heap memory and stores it in the String constant pool. Note that, if another String with the same contents exists in the String constant pool, then a new object won't be created and the new reference will point to the other String.
         String s3 = s2.intern();
         System.out.print(s3 == s1);//"It will print true s1,s3 in Constant Pool "
         String s="123";
         int sum =0;
         for (int i = 0; i < s.length(); i++) {
             sum=sum+Integer.parseInt(s.charAt(i)+"");
             }
          System.out.println("Sum of all the digit present in String : "+sum);
         }
         }