package interviewTraining;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Java8StreamProgram {
	public static void main(String arg[]) {
		List<String> list = Arrays.asList("A","B","C","C","D");
		//Remove duplicate value using Stream get distinct value 
		List<String> distinctVaue = list.stream().distinct().collect(Collectors.toList());
		System.out.println(distinctVaue);
		
		List<Integer> num = Arrays.asList(3,2,4);
		//Squre of given List
		List<Integer> sqr= num.stream().map(s->s*s).collect(Collectors.toList());
		System.out.println(sqr);
			
	}
}
