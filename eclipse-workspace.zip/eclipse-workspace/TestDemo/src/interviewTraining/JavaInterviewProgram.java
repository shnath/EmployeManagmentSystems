package interviewTraining;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class JavaInterviewProgram {

    public static void main(String[] args) {
    	
        List<String> list = Arrays.asList("A", "B", "C", "D", "A", "B", "C");

    	List<String> l = list.stream().distinct().collect(Collectors.toList());
    	System.out.print(l);
    	
    	List<Integer> even = Arrays.asList(2,6,3,5,4,10);
    	
    	List<Integer> eventList = even.stream().filter(x->x%2==0).collect(Collectors.toList());
    	System.out.print(eventList);
    	
    	
    	List<Integer> num = Arrays.asList(2,3,4,5);
    	
    	List<Integer> sqr = num.stream().map(x->x*x).collect(Collectors.toList());
    	
    	System.out.println(sqr);
    	
    	
	   String str="AAaaBBBcB";
		
		System.out.println(str);
		HashMap<Character, Integer> map = new HashMap<>(); 
		for(Integer i = 0; i<str.length();i++) {
			char c = str.charAt(i);
			if(map.containsKey(c)){
				map.put(c,map.get(c)+1);
			}else {
				map.put(c, 1);
			}
			
		}
		System.out.println(map);
    
		/*
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); Calendar
		 * cal = Calendar.getInstance(); String requestDateTo =
		 * sdf.format(cal.getTime()); cal.add(Calendar.DAY_OF_MONTH, -90); String
		 * requestDateFrom = sdf.format(cal.getTime());
		 * 
		 * System.out.println(requestDateFrom); System.out.println(requestDateTo);
		 */        

    	SingletonClass ob1 = SingletonClass.getInstance();
    	SingletonClass ob2 = SingletonClass.getInstance();
    	SingletonClass ob3 = SingletonClass.getInstance();
    	
    	System.out.println(ob1.hashCode());
    	System.out.println(ob2.hashCode());
    	System.out.println(ob3.hashCode());

    }
    
}