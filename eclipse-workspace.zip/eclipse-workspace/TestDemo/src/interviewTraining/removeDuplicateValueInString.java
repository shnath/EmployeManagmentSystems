package interviewTraining;

import java.util.LinkedHashSet;

public class removeDuplicateValueInString {
	public static void main(String[] a) {
		String str = "geeksforgeeks";

		LinkedHashSet<Character> set = new LinkedHashSet<>(str.length() -1);

		for (char x : str.toCharArray()) {
            set.add(x);	
		}
		for (char c : set) {
			System.out.print(c);
		}

	}
}
