package interviewTraining.interfacesExample;

public interface Bank {
	int rateOfInterest(); 
}
