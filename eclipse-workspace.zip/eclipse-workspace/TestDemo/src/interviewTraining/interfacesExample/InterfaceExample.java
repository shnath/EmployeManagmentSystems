package interviewTraining.interfacesExample;

class NationalBank implements Bank{

	@Override
	public int rateOfInterest() {
		System.out.println("Interest Bank of National "+5);
		return 5;
	}
	
}

class HBL implements Bank{

	@Override
	public int rateOfInterest() {
		System.out.println("Interest Bank of HBL "+7);
		return 7;
	}
	
}

class InterfaceExample {
	
	public static void main (String ar[]) {
		NationalBank national= new NationalBank();
		national.rateOfInterest();
		HBL hb = new HBL();
		hb.rateOfInterest();
	}
}