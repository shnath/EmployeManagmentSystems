package interviewTraining.interfacesExample;

@FunctionalInterface
interface Shape {
	
	void draw(int width);
}


 //# without create class to give the implementation of Shape  we use annonyous class  
	/*
	 * class Rectangle implements Shape{
	 * 
	 * @Override public void draw() { System.out.println("Draw Shape Rectangel"); }
	 * 
	 * }
	 */
 
class FunctionalInterfaceExample {
	
	public static void main (String ar[]) {
		Shape r = 
			(width) ->{
				System.out.println("Draw Shape Rectangel "+width);				
			};
		r.draw(5);
	}
	
}