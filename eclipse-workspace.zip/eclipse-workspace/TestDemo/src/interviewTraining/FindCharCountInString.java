package interviewTraining;

import java.util.HashMap;

public class FindCharCountInString {
	public static void main(String arg[]) {
		String str="AABBDDD";
		
		HashMap<Character,Integer> map = new HashMap<Character, Integer>();
		int count = 1;
		for (int i = 0; i <str.length();i++) {
			char c = str.charAt(i);
			if(map.containsKey(c)) {
				map.put(c, count++);
			}else {
				map.put(c, 1);
			}
		}
		System.out.print(""+map.toString());
	}
}
