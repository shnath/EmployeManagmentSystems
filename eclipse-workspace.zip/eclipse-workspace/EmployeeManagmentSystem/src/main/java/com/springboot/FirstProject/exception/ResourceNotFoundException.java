package com.springboot.FirstProject.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;
	private String errorMessage;
	private String errorCode;

	public String getErrorMessage() {
		return errorMessage;
	}
	public ResourceNotFoundException(String errorMessage, String errorCode) {
		super(String.format("%s: %s", errorMessage,errorCode));
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	

}
