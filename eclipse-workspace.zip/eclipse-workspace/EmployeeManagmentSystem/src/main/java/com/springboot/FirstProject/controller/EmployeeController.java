package com.springboot.FirstProject.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.FirstProject.dto.EmployeeDto;
import com.springboot.FirstProject.service.EmployeeService;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

	private EmployeeService employeeService;

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}

	// build create Employee Rest API
	@PostMapping("/save")
	public ResponseEntity<EmployeeDto> saveEmployee(@Valid @RequestBody EmployeeDto empDto) {

		EmployeeDto employeeDto = employeeService.saveEmployee(empDto);

		return new ResponseEntity<EmployeeDto>(employeeDto, HttpStatus.CREATED);
	}

	// build get All Employees Rest API
	@GetMapping("/employeeList")
	public List<EmployeeDto> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	// build get Employee By Id Rest API

	@GetMapping("/employeeById/{id}")
	public ResponseEntity<EmployeeDto> getEmployeeById(@PathVariable("id") long employeeId) {

		EmployeeDto employeeDto = employeeService.getEmployeeById(employeeId);

		return new ResponseEntity<EmployeeDto>(employeeDto, HttpStatus.OK);
	}

	// build update Employee Rest API

	@PutMapping("/updateEmployee/{id}")
	public ResponseEntity<EmployeeDto> updateEmployee(@PathVariable long id, @RequestBody EmployeeDto employee) {

		EmployeeDto emp = employeeService.updateEmployee(employee, id);

		return new ResponseEntity<EmployeeDto>(emp, HttpStatus.OK);
	}

	// build delete Employee Rest API
	@DeleteMapping("/deleteEmployee/{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable long id) {
		employeeService.deleteEmployee(id);
		return new ResponseEntity<String>("Employee Delete Successfully ", HttpStatus.OK);
	}
}
