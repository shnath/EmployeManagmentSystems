package com.springboot.FirstProject.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.FirstProject.dto.EmployeeDto;
import com.springboot.FirstProject.exception.ResourceNotFoundException;
import com.springboot.FirstProject.model.Employee;
import com.springboot.FirstProject.repository.EmployeeRepository;
import com.springboot.FirstProject.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	// we don't need to add @Transactional Annotion in employeeServerImp class
	// becuase Data JPA Repository provide Transactional to all it's methods
	private EmployeeRepository employeeRepository;

	@Autowired
	private ModelMapper mapper;

	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}

	@Override
	@Transactional
	public EmployeeDto saveEmployee(EmployeeDto emp) {

		Employee employeEnitity = dtoToEntityModelMapper(emp);
		Employee savedEntity = employeeRepository.save(employeEnitity);
		return entityToDtoModelMapper(savedEntity);

	}

	@Override
	public List<EmployeeDto> getAllEmployees() {

		return entityToDtoModelMapperList(employeeRepository.findAll());
	}

	@Override
	public EmployeeDto getEmployeeById(long id) {
		Optional<Employee> emp = employeeRepository.findById(id);
		if (emp.isPresent()) {
			return entityToDtoModelMapper(emp.get());
		} else {
			throw new ResourceNotFoundException("Employee Not Found with user Id " + id, "EMP_NOT_FOUND");
		}
	}

	@Override
	public EmployeeDto updateEmployee(EmployeeDto emp, long id) {
		// first we will check employee is existing or not in DB
		Employee existing = employeeRepository.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Employee Not Found with user Id " + id, "EMP_NOT_FOUND"));
		existing.setFirstName(emp.getFirstName());
		existing.setLastName(emp.getLastName());
		existing.setEmail(emp.getEmail());

		// save the existing object in DB
		employeeRepository.save(existing);

		return entityToDtoModelMapper(existing);

	}

	@Override
	public void deleteEmployee(long id) {
		// check employee is existing or not in DB
		employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee Not Found with" + id, "EMP_NOT_FOUND"));
		employeeRepository.deleteById(id);
	}

	private EmployeeDto entityToDtoModelMapper(Employee entity) {
		return mapper.map(entity, EmployeeDto.class);
	}

	private List<EmployeeDto> entityToDtoModelMapperList(List<Employee> employeeEntityList) {
		
		List<EmployeeDto> employeeDtoList = employeeEntityList
				.stream()
				.map(entity-> mapper.map(entity, EmployeeDto.class))
				.collect(Collectors.toList());
			
		return employeeDtoList;
		

		
	}

	private Employee dtoToEntityModelMapper(EmployeeDto dto) {
		return mapper.map(dto, Employee.class);
	}
}
