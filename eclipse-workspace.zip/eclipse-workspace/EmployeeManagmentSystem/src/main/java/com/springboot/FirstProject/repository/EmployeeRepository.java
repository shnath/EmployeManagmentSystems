package com.springboot.FirstProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.FirstProject.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{
	
	
}