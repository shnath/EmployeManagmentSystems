package com.springboot.FirstProject.exception;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<APIResponse> resourceNotFoundExceptionHandler(ResourceNotFoundException ex){
		APIResponse response = new APIResponse(ex.getErrorMessage(),ex.getErrorCode(),HttpStatus.NOT_FOUND.toString());
				
		return new ResponseEntity<APIResponse>(response,HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,String>> argumentNotValidHandler(MethodArgumentNotValidException ex){
		
		Map<String, String> resp = new HashMap<String, String>();
		List<ObjectError> error = ex.getBindingResult().getAllErrors();
		
		for(ObjectError e:error) {
			String fieldName = ((FieldError) e).getField();
			String errorMessage = e.getDefaultMessage();
			resp.put(fieldName, errorMessage);
		}
		return new ResponseEntity<Map<String,String>>(resp,HttpStatus.BAD_REQUEST); 
	}
}
