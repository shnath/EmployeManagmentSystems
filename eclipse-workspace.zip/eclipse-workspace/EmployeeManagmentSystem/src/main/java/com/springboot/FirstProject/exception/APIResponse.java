package com.springboot.FirstProject.exception;

public class APIResponse {
	
	private String message;
	private String code;
	private String status;
	
	public APIResponse(String Message, String Code, String Status) {
		super();
		this.message = Message;
		this.code = Code;
		this.status = Status;
	}
	public String getMessage() {
		return message;
	}
	public String getCode() {
		return code;
	}
	public String getStatus() {
		return status;
	}
	public void setMessage(String Message) {
		this.message = Message;
	}
	public void setCode(String Code) {
		this.code = Code;
	}
	public void setStatus(String Status) {
		this.status = Status;
	}


}
