package com.springboot.FirstProject.service;

import java.util.List;

import com.springboot.FirstProject.dto.EmployeeDto;

//we don't need to add @repository Annotion in employeeRepository interface because Data JPA Repository already take care this
public interface EmployeeService {
	EmployeeDto saveEmployee(EmployeeDto emp);
	List<EmployeeDto> getAllEmployees();
	EmployeeDto getEmployeeById(long id);
	EmployeeDto updateEmployee(EmployeeDto emp,long id);
	void deleteEmployee(long id);
}
