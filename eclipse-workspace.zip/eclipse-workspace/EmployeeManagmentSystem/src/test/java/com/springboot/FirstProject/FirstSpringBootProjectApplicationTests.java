package com.springboot.FirstProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
