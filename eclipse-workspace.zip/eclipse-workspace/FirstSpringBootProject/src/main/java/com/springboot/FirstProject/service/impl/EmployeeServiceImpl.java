package com.springboot.FirstProject.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.springboot.FirstProject.exception.ResourceNotFoundException;
import com.springboot.FirstProject.model.Employee;
import com.springboot.FirstProject.repository.EmployeeRepository;
import com.springboot.FirstProject.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	//we don't need to add @Transactional Annotion in employeeServerImp class becuase Data JPA Repository provide Transactional to all it's methods
	private EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}

	@Override
	public Employee saveEmployee(Employee emp) {
		return employeeRepository.save(emp);
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}
	
	@Override
	public Employee getEmployeeById(long id) {
		Optional<Employee> emp= employeeRepository.findById(id);
			if(emp.isPresent()) {
				return emp.get();
			}else{
				throw new ResourceNotFoundException("Employee Not Found with"+ id , "EMP_NOT_FOUND");
			}
	}

	@Override
	public Employee updateEmployee(Employee emp, long id) {
		// first we will check employee is existing or not in DB
		Employee existing = employeeRepository.findById(id).orElseThrow(()->  new ResourceNotFoundException("Employee Not Found with"+ id , "EMP_NOT_FOUND"));
		existing.setFirstName(emp.getFirstName());
		existing.setLastName(emp.getLastName());
		existing.setEmail(emp.getEmail());
		
		//save the existing object in DB
		employeeRepository.save(existing);
		
		return existing;
		
	}

	@Override
	public void deleteEmployee(long id) {
		//check employee is existing or not in DB
		employeeRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Employee Not Found with"+ id , "EMP_NOT_FOUND"));
		employeeRepository.deleteById(id);
	}

}
