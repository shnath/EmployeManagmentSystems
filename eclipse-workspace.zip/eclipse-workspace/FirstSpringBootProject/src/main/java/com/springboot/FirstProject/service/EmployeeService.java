package com.springboot.FirstProject.service;

import java.util.List;

import com.springboot.FirstProject.model.Employee;

//we don't need to add @repository Annotion in employeeRepository interface because Data JPA Repository already take care this
public interface EmployeeService {
	Employee saveEmployee(Employee emp);
	List<Employee> getAllEmployees();
	Employee getEmployeeById(long id);
	Employee updateEmployee(Employee emp,long id);
	void deleteEmployee(long id);
}
