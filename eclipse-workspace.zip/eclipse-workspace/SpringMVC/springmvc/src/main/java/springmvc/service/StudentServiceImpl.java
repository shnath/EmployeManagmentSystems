package springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import springmvc.dao.StudentDAO;
import springmvc.model.Student;

@Service
@Transactional
public class StudentServiceImpl implements StudentService{

	@Autowired 
	StudentDAO studentDAO;
	public void saveStudent(Student std) {
		System.out.print("Server Impl");
		studentDAO.saveStudent(std);
	}
	
	public void deleteStudent(Student std) {
		//studentRepo.delete(std);
	}
	
	public List<Student> getStudent() {
		return studentDAO.getStudent();
	}

}
