package springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import springmvc.model.Student;
import springmvc.service.StudentService;

@Controller
public class StudentController {
	
	@Autowired
	StudentService stdService;
	
	@RequestMapping(path="/studentForm",method=RequestMethod.GET)
	public ModelAndView showForm() {
		ModelAndView view = new ModelAndView();
		view.setViewName("studentform");
		return view;
		
	}
	
	@PostMapping("/saveStudent")
	public ModelAndView populateData(@ModelAttribute Student std,ModelAndView view) {
		stdService.saveStudent(std);
		view.setViewName("facebook");
		return view;
	}
	/*@RequestMapping(path="/saveStudent",method=RequestMethod.POST)
	public ModelAndView populateData(
			@RequestParam("first") String firstName,
			@RequestParam("last") String lastName,
			@RequestParam("rollNo") Integer rollNo) {
		ModelAndView view= new ModelAndView();
		m
		view.addObject("stdName",firstName.concat(lastName));
		view.addObject("stdRoll",rollNo);
		view.setViewName("studentView");
		
		
		return view;
	}*/
	
	@RequestMapping(path="/studentSearchView",method=RequestMethod.GET)
	public String studentSearchView(Model m) {
		
		return "/studentSearch";
	}
	
}
