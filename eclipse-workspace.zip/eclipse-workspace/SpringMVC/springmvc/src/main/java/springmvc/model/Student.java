package springmvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student")
public class Student {
   
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)

	private Integer stdId;
	private String admission_no;
	private String roll_no;
	private Integer class_id;
	private Integer section_id;
	private String firstname;
	private String lastname;
	private String gender;
	private String dob;
	
	public String getAdmission_no() {
		return admission_no;
	}
	public void setAdmission_no(String admission_no) {
		this.admission_no = admission_no;
	}
	public String getRoll_no() {
		return roll_no;
	}
	public void setRoll_no(String roll_no) {
		this.roll_no = roll_no;
	}
	public Integer getClass_id() {
		return class_id;
	}
	public void setClass_id(Integer class_id) {
		this.class_id = class_id;
	}
	public Integer getSection_id() {
		return section_id;
	}
	public void setSection_id(Integer section_id) {
		this.section_id = section_id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return "Student [admission_no=" + admission_no + ", roll_no=" + roll_no + ", class_id=" + class_id
				+ ", section_id=" + section_id + ", firstname=" + firstname + ", lastname=" + lastname + ", gender="
				+ gender + ", dob=" + dob + "]";
	}
	
	
}
