package springmvc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import springmvc.model.Student;

@Component
public class StudentDAOImpl implements StudentDAO{

	@Autowired
	HibernateTemplate hibernateTemp;
	
	public void saveStudent(Student std) {
		this.hibernateTemp.save(std);
	}

	public void deleteStudent(Student std) {
		this.hibernateTemp.delete(std);
	}

	public List<Student> getStudent() {
		List<Student> studentList = this.hibernateTemp.loadAll(Student.class);
		return studentList;
	}
	
}
