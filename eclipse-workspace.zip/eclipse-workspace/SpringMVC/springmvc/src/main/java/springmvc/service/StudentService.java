package springmvc.service;

import java.util.List;

import springmvc.model.Student;

public interface StudentService {
	
	public void saveStudent(Student std);
	
	public void deleteStudent(Student std);
	
	public List<Student> getStudent();
}
