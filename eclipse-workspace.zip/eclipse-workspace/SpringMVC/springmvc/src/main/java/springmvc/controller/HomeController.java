package springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
//@RequestMapping("/firstController")
public class HomeController {
	
	//@RequestMapping("/home") //1st way
	@RequestMapping(path="/home",method=RequestMethod.GET) //2nd way with http methods
	public String home(Model model) {
	
		ArrayList<String> studentList= new ArrayList<String>();
		
		studentList.add("Shanker Nath");
		studentList.add("Ravi Nath");
		studentList.add("Beesham Nath");
		model.addAttribute("studentList",studentList);
		return "home";//view name means jsp name 
	
	}
	
	@RequestMapping("/about")
	public ModelAndView about() {
		
		ModelAndView modelandView = new ModelAndView();
		
		modelandView.addObject("name","Sachal Joyo");
		modelandView.addObject("job","Java Developer");
		
		List<Integer> mark= new ArrayList<Integer>();
		mark.add(250);
		mark.add(200);
		mark.add(300);
		
		modelandView.addObject("studentMarks",mark);
		
		modelandView.setViewName("about");//view name means jsp name 
		
		return modelandView;
	}
	@GetMapping("/facebook")
	public String facebook() {
		return "facebook";
	}
}
