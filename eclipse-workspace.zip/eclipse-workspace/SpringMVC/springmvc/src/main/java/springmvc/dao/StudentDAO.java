package springmvc.dao;

import java.util.List;

import springmvc.model.Student;

public interface StudentDAO {
	
	public void saveStudent(Student std);
	
	public void deleteStudent(Student std);
	
	public List<Student> getStudent();

}
