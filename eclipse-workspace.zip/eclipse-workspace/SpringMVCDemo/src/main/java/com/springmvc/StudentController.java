package com.springmvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class StudentController {

	@RequestMapping("/studentview")
	public String displayStudent() {
		System.out.print("Hello World");
		return "welcome";
	}
	
	@GetMapping("/addNewStudent")
	public String addNewStudent() {
		
		return "newStudentForm";
	}
}
